-- ============================================================================
--  FMSecure / Tenant-Server  ·  Neon Postgres Setup & Repair Script
--  ---------------------------------------------------------------------------
--  Idempotent: safe to run on a fresh Neon DB OR on an existing one.
--  Will CREATE every missing table, CREATE every missing index, and ADD every
--  missing column the application expects. No data is dropped or modified.
--
--  How to run:
--      1. Open Neon Console -> your project -> SQL Editor
--      2. Paste this entire file
--      3. Click "Run"
--      4. Expect: "Success.  No rows returned." for every block.
-- ============================================================================

-- Required extension for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ── 1. Public / marketing tables ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contact_submissions (
    id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
    name        TEXT NOT NULL,
    email       TEXT NOT NULL,
    type        TEXT NOT NULL DEFAULT 'general',
    company     TEXT NOT NULL DEFAULT '',
    seats       TEXT NOT NULL DEFAULT '',
    subject     TEXT NOT NULL DEFAULT '',
    message     TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS enterprise_leads (
    id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
    company     TEXT NOT NULL,
    name        TEXT NOT NULL,
    email       TEXT NOT NULL,
    seats       TEXT NOT NULL DEFAULT '10',
    message     TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'new',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── 2. Licensing / billing tables ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS licenses (
    license_key TEXT PRIMARY KEY,
    email       TEXT NOT NULL,
    tier        TEXT NOT NULL DEFAULT 'pro_monthly',
    payment_id  TEXT,
    order_id    TEXT,
    expires_at  TIMESTAMPTZ NOT NULL,
    active      BOOLEAN NOT NULL DEFAULT TRUE,
    machine_id  TEXT DEFAULT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pending_orders (
    order_id   TEXT PRIMARY KEY,
    email      TEXT NOT NULL,
    tier       TEXT NOT NULL,
    amount     INTEGER NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS versions (
    id            SERIAL PRIMARY KEY,
    version       TEXT NOT NULL,
    release_notes TEXT NOT NULL DEFAULT '',
    download_url  TEXT NOT NULL DEFAULT '',
    changelog_url TEXT NOT NULL DEFAULT '',
    published_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_current    BOOLEAN NOT NULL DEFAULT TRUE
);

-- ── 3. Multi-tenant core tables ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tenants (
    id            TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
    name          TEXT NOT NULL,
    slug          TEXT UNIQUE NOT NULL,
    api_key       TEXT UNIQUE NOT NULL,
    plan          TEXT NOT NULL DEFAULT 'business',
    max_agents    INTEGER NOT NULL DEFAULT 10,
    contact_email TEXT NOT NULL DEFAULT '',
    notes         TEXT NOT NULL DEFAULT '',
    active        BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tenant_agents (
    id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
    tenant_id        TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    machine_id       TEXT NOT NULL,
    hostname         TEXT NOT NULL DEFAULT '',
    ip_address       TEXT NOT NULL DEFAULT '',
    os_info          TEXT NOT NULL DEFAULT '',
    agent_version    TEXT NOT NULL DEFAULT '2.5.0',
    username         TEXT NOT NULL DEFAULT '',
    tier             TEXT NOT NULL DEFAULT 'free',
    is_armed         BOOLEAN NOT NULL DEFAULT FALSE,
    status           TEXT NOT NULL DEFAULT 'offline',
    last_seen        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    registered_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sigma_rule_count INTEGER DEFAULT 0,
    UNIQUE(tenant_id, machine_id)
);

CREATE TABLE IF NOT EXISTS tenant_users (
    id            TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
    tenant_id     TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    email         TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'admin',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, email)
);

CREATE TABLE IF NOT EXISTS tenant_alerts (
    id           TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
    tenant_id    TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    agent_id     TEXT REFERENCES tenant_agents(id) ON DELETE SET NULL,
    machine_id   TEXT NOT NULL DEFAULT '',
    hostname     TEXT NOT NULL DEFAULT '',
    severity     TEXT NOT NULL DEFAULT 'INFO',
    event_type   TEXT NOT NULL DEFAULT '',
    message      TEXT NOT NULL DEFAULT '',
    file_path    TEXT NOT NULL DEFAULT '',
    acknowledged BOOLEAN NOT NULL DEFAULT FALSE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tenant_config (
    tenant_id       TEXT PRIMARY KEY REFERENCES tenants(id) ON DELETE CASCADE,
    webhook_url     TEXT NOT NULL DEFAULT '',
    alert_email     TEXT NOT NULL DEFAULT '',
    verify_interval INTEGER NOT NULL DEFAULT 60,
    max_vault_mb    INTEGER NOT NULL DEFAULT 10,
    allowed_exts    TEXT NOT NULL DEFAULT '.txt,.json,.py,.html,.js,.css',
    retention_days  INTEGER NOT NULL DEFAULT 90,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── 4. Audit / GDPR ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS erasure_log (
    id           SERIAL PRIMARY KEY,
    tenant_id    TEXT NOT NULL,
    tenant_name  TEXT NOT NULL,
    erased_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    requested_by TEXT NOT NULL DEFAULT 'api',
    requester_ip TEXT NOT NULL DEFAULT '',
    rows_deleted INTEGER NOT NULL DEFAULT 0
);

-- ── 5. Indexes (performance) ────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_erasure_log_tenant
    ON erasure_log(tenant_id, erased_at DESC);

CREATE INDEX IF NOT EXISTS idx_tenant_agents_tenant
    ON tenant_agents(tenant_id);

CREATE INDEX IF NOT EXISTS idx_tenant_alerts_tenant_sev
    ON tenant_alerts(tenant_id, severity, created_at DESC);

-- ── 6. Repair missing columns on pre-existing tables ────────────────────────
--    (covers older DBs that may have been created by an earlier app version)

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                    WHERE table_name='tenant_agents' AND column_name='sigma_rule_count')
    THEN ALTER TABLE tenant_agents ADD COLUMN sigma_rule_count INTEGER DEFAULT 0; END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                    WHERE table_name='tenant_config' AND column_name='retention_days')
    THEN ALTER TABLE tenant_config ADD COLUMN retention_days INTEGER NOT NULL DEFAULT 90; END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                    WHERE table_name='tenant_config' AND column_name='updated_at')
    THEN ALTER TABLE tenant_config ADD COLUMN updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(); END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                    WHERE table_name='tenants' AND column_name='active')
    THEN ALTER TABLE tenants ADD COLUMN active BOOLEAN NOT NULL DEFAULT TRUE; END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                    WHERE table_name='tenants' AND column_name='notes')
    THEN ALTER TABLE tenants ADD COLUMN notes TEXT NOT NULL DEFAULT ''; END IF;
END $$;

-- ── 7. Seed: ensure at least one row in `versions` ──────────────────────────
INSERT INTO versions (version, release_notes, download_url, changelog_url, is_current)
SELECT '2.5.0', 'Initial release', '/download', '/changelog', TRUE
WHERE NOT EXISTS (SELECT 1 FROM versions);

-- ── 8. Final sanity check ───────────────────────────────────────────────────
SELECT 'OK  ·  '
       || (SELECT COUNT(*) FROM information_schema.tables
           WHERE table_schema='public'
             AND table_name IN ('tenants','tenant_agents','tenant_users',
                                'tenant_alerts','tenant_config','erasure_log',
                                'versions','licenses','pending_orders',
                                'contact_submissions','enterprise_leads'))
       || ' / 11 expected tables present'  AS status;
